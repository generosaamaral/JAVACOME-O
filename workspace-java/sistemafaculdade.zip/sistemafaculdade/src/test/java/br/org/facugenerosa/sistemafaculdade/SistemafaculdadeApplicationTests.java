package br.org.facugenerosa.sistemafaculdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemafaculdadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
